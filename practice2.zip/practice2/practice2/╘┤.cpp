#include<iostream>
using namespace std;
class Solution {
public:
	int Judge(int x) {
		int temp = 0, sum = 0,s;
		s = x % 10;
		while ((x > 0)&&(s!=0)) {
			temp = x % 10;
			sum = sum * 10 + temp;
			x = x / 10;
		}
		return sum;
	}
	
};
int main() {
	int a;
	cout << "������Ҫ�жϵ���" << endl;
	cin >> a;
	Solution A;
	if (a == A.Judge(a))
		cout << "ture" << endl;
	else
		cout << "false" << endl;
	return 0;
}